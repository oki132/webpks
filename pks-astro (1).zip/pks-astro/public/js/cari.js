window.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('pencarian');
  const q = new URLSearchParams(location.search).get('q');
  // eslint-disable-next-line no-undef
  const ui = new PagefindUI({ element: '#pencarian', baseUrl: el.dataset.base || '/', showSubResults: true, translations: { placeholder: 'Ketik kata kunci…' } });
  if (q) ui.triggerSearch(q);
});
