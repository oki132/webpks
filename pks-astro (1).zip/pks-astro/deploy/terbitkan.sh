#!/usr/bin/env bash
# Build dan terbitkan di server (tanpa CI). Pemakaian: ~/terbitkan.sh
set -euo pipefail
cd "$HOME/pks-website"
git pull --ff-only || true
npm ci && npm run build
REL=/var/www/pks/releases/$(date +%Y%m%d-%H%M%S)
cp -r dist "$REL" && ln -sfn "$REL" /var/www/situs/web
ls -1dt /var/www/pks/releases/* | tail -n +6 | xargs -r rm -rf
echo "Terbit: $REL"
