import { defineCollection, reference, z } from 'astro:content';
import { file, glob } from 'astro/loaders';

const md = (folder: string) => glob({ pattern: '**/*.md', base: `./src/content/${folder}` });
/** File JSON yang ditulis Decap CMS berbentuk { "<kunci>": [...] } */
const json = (path: string, key: string) => file(path, { parser: (t) => JSON.parse(t)[key] });

/** 7 tema = 7 jalur. Warna tiap kode diatur di global.css (.tema-xx). */
const tema = defineCollection({
  loader: json('./src/data/tema.json', 'tema'),
  schema: z.object({ kode: z.string().length(2), nama: z.string(), ringkas: z.string(), urutan: z.number() }),
});

/** Isu = satu elemen. Isu dengan >1 tema otomatis menjadi "simpul lintas tema". */
const isu = defineCollection({
  loader: md('isu'),
  schema: z.object({
    simbol: z.string().length(2),
    nama: z.string(),
    tema: z.array(reference('tema')).min(1),
    urgensi: z.enum(['mendesak', 'berkembang', 'laten']),
    ringkas: z.string(),
    pohonMasalah: z.object({
      dampak: z.array(z.string()).default([]),
      gejala: z.array(z.string()).default([]),
      akar: z.array(z.string()).default([]),
    }),
    diperbarui: z.coerce.date(),
  }),
});

const indikator = defineCollection({
  loader: json('./src/data/indikator.json', 'indikator'),
  schema: z.object({
    nama: z.string(), nilai: z.string(), tahun: z.number(), sumber: z.string(),
    tema: reference('tema'), isu: reference('isu').optional(),
  }),
});

/** Regulasi + kartu tinjauan. `cakupan` menyusun peta celah secara otomatis. */
const regulasi = defineCollection({
  loader: md('regulasi'),
  schema: z.object({
    nama: z.string(), singkat: z.string(), tahun: z.number(),
    jenis: z.enum(['UU', 'PP', 'Perpres', 'Permen', 'Strategi', 'Lainnya']),
    tema: z.array(reference('tema')),
    tinjauan: z.object({ status: z.string(), tujuan: z.string(), sudahBerjalan: z.string(), celah: z.string() }),
    pasalKunci: z.array(z.object({ pasal: z.string(), isi: z.string() })).default([]),
    cakupan: z.array(z.object({ isu: reference('isu'), status: z.enum(['diatur', 'sebagian', 'tumpang-tindih']) })).default([]),
  }),
});

const benchmark = defineCollection({
  loader: json('./src/data/benchmark.json', 'benchmark'),
  schema: z.object({
    topik: z.string(), tema: reference('tema'),
    negara: z.array(z.string()),
    aspek: z.array(z.object({ nama: z.string(), nilai: z.array(z.string()) })),
  }),
});

const praktik = defineCollection({
  loader: md('praktik'),
  schema: z.object({ judul: z.string(), pelaksana: z.string(), wilayah: z.string(), tema: z.array(reference('tema')), pelajaran: z.string() }),
});

/**
 * Kajian berpindah sendiri sesuai tahap: selama belum "terbit" tampil di "Sedang di jalur";
 * setelah "terbit" otomatis masuk Pustaka dan "Baru diluncurkan".
 */
export const TAHAP = ['perumusan', 'pengumpulan-data', 'analisis', 'konsultasi', 'terbit'] as const;
const kajian = defineCollection({
  loader: md('kajian'),
  schema: z.object({
    judul: z.string(),
    jenis: z.enum(['policy-paper', 'policy-brief', 'working-paper', 'laporan-tahunan']),
    tema: z.array(reference('tema')).min(1),
    tahap: z.enum(TAHAP),
    perkiraanTerbit: z.string().optional(),
    tanggalTerbit: z.coerce.date().optional(),
    penulis: z.array(z.string()).default([]),
    ringkasan30: z.string(),
    berkas: z.string().optional(),
    isu: z.array(reference('isu')).default([]),
    regulasi: z.array(reference('regulasi')).default([]),
    konsultasi: reference('konsultasi').optional(),
    unggulan: z.boolean().default(false),
  }),
});

export const STATUS_REK = ['dikaji', 'diserahkan', 'dibahas', 'diterima', 'diterapkan'] as const;
const rekomendasi = defineCollection({
  loader: md('rekomendasi'),
  schema: z.object({
    judul: z.string(), tema: z.array(reference('tema')).min(1), ditujukanKepada: z.string(),
    status: z.enum(STATUS_REK), kajian: reference('kajian').optional(),
    catatan: z.array(z.object({ tanggal: z.coerce.date(), status: z.string(), isi: z.string() })).default([]),
  }),
});

const dataset = defineCollection({
  loader: md('dataset'),
  schema: z.object({
    judul: z.string(), tema: z.array(reference('tema')), format: z.array(z.string()),
    diperbarui: z.coerce.date(), sumber: z.string(), lisensi: z.string().default('CC BY 4.0'), berkas: z.string().optional(),
  }),
});

const tulisan = defineCollection({
  loader: md('tulisan'),
  schema: z.object({
    judul: z.string(), jenis: z.enum(['opini', 'kolom-pakar', 'catatan-riset', 'artikel-populer']),
    penulis: z.string(), afiliasi: z.string(), tema: z.array(reference('tema')), tanggal: z.coerce.date(), ringkas: z.string(),
  }),
});

const event = defineCollection({
  loader: md('event'),
  schema: z.object({
    judul: z.string(), jenis: z.enum(['peluncuran', 'forum', 'webinar', 'diskusi-terpumpun']),
    tanggal: z.coerce.date(), waktu: z.string(), tempat: z.string(), tema: z.array(reference('tema')),
    penting: z.boolean().default(false), terbuka: z.boolean().default(true),
    susunan: z.array(z.object({ jam: z.string(), acara: z.string() })).default([]),
    pembicara: z.array(z.object({ nama: z.string(), peran: z.string() })).default([]),
    rekaman: z.string().optional(),
  }),
});

const berita = defineCollection({
  loader: md('berita'),
  schema: z.object({ judul: z.string(), jenis: z.enum(['berita', 'siaran-pers']), tanggal: z.coerce.date() }),
});

const konsultasi = defineCollection({
  loader: md('konsultasi'),
  schema: z.object({
    judul: z.string(), tema: z.array(reference('tema')), dibuka: z.coerce.date(), ditutup: z.coerce.date(),
    status: z.enum(['dibuka', 'ditutup']),
    bagian: z.array(z.object({ judul: z.string(), isi: z.string() })),
    tindakLanjut: z.array(z.object({ masukan: z.string(), tindakan: z.string(), status: z.enum(['diakomodasi', 'dipertimbangkan', 'belum-diakomodasi']) })).default([]),
  }),
});

/** Toolkit: alat siap pakai. `pertanyaan` mengaktifkan daftar periksa interaktif (asesmen mandiri). */
export const JENIS_TOOLKIT = ['asesmen', 'templat', 'kalkulator', 'kanvas', 'modul'] as const;
const toolkit = defineCollection({
  loader: md('toolkit'),
  schema: z.object({
    judul: z.string(),
    jenis: z.enum(JENIS_TOOLKIT),
    tema: z.array(reference('tema')).min(1),
    sasaran: z.string(),
    format: z.string(),
    durasi: z.string().optional(),
    status: z.enum(['tersedia', 'segera']),
    ringkas: z.string(),
    berkas: z.string().optional(),
    pertanyaan: z.array(z.string()).default([]),
    regulasi: z.array(reference('regulasi')).default([]),
    isu: z.array(reference('isu')).default([]),
  }),
});

/** Pengaturan beranda (satu entri). */
const beranda = defineCollection({
  loader: file('./src/data/beranda.json'),
  schema: z.object({
    pertanyaanBulanIni: z.string(), temaPertanyaan: reference('tema'), kajianPertanyaan: reference('kajian').optional(),
    angkaSorotan: z.string(), labelSorotan: z.string(), sumberSorotan: z.string(),
    pertanyaanPekanIni: z.string(), opsiPolling: z.array(z.string()).min(2),
  }),
});

export const collections = { tema, isu, indikator, regulasi, benchmark, praktik, kajian, rekomendasi, dataset, tulisan, event, berita, konsultasi, toolkit, beranda };
