// Interaksi kecil seluruh situs. Dibundel Astro sebagai file terpisah (aman untuk CSP).

// ---------- Dropdown menu ----------
const navButtons = Array.from(document.querySelectorAll<HTMLButtonElement>('.nav-btn'));
const panelOf = (b: HTMLElement) => document.getElementById(b.getAttribute('aria-controls') ?? '');
function closeAll(except: HTMLElement | null) {
  navButtons.forEach((b) => {
    if (b === except) return;
    b.setAttribute('aria-expanded', 'false');
    const p = panelOf(b); if (p) p.hidden = true;
  });
}
navButtons.forEach((b) => b.addEventListener('click', () => {
  const open = b.getAttribute('aria-expanded') === 'true';
  closeAll(b);
  b.setAttribute('aria-expanded', String(!open));
  const p = panelOf(b); if (p) p.hidden = open;
}));
document.addEventListener('click', (e) => { if (!(e.target as Element).closest('.nav-item')) closeAll(null); });
document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  const open = navButtons.find((b) => b.getAttribute('aria-expanded') === 'true');
  closeAll(null); open?.focus();
});

// ---------- Menu ponsel ----------
const toggle = document.querySelector<HTMLButtonElement>('.menu-toggle');
const nav = document.getElementById('nav-utama');
toggle?.addEventListener('click', () => {
  const open = toggle.getAttribute('aria-expanded') === 'true';
  toggle.setAttribute('aria-expanded', String(!open));
  nav?.classList.toggle('is-open', !open);
});

// ---------- Saring (chips) ----------
// <div class="chips" data-saring="id-wadah" data-kunci="urgensi"> + elemen berisi data-urgensi="..."
document.querySelectorAll<HTMLElement>('.chips').forEach((group) => {
  group.addEventListener('click', (e) => {
    const chip = (e.target as Element).closest<HTMLButtonElement>('.chip');
    if (!chip) return;
    group.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', 'false'));
    chip.setAttribute('aria-pressed', 'true');
    const target = group.dataset.saring, key = group.dataset.kunci, val = chip.dataset.nilai;
    if (!target || !key || !val) return;
    document.querySelectorAll<HTMLElement>(`#${target} [data-${key}]`).forEach((el) => {
      const cocok = val === 'semua' || (el.dataset[key] ?? '').split(' ').includes(val);
      if (el.classList.contains('elemen')) el.classList.toggle('is-dim', !cocok);
      else el.hidden = !cocok;
    });
  });
});

// ---------- Tab ----------
document.querySelectorAll<HTMLElement>('[data-tabs]').forEach((list) => {
  const tabs = Array.from(list.querySelectorAll<HTMLButtonElement>('[role="tab"]'));
  const select = (t: HTMLButtonElement) => tabs.forEach((x) => {
    const on = x === t;
    x.setAttribute('aria-selected', String(on)); x.tabIndex = on ? 0 : -1;
    const p = panelOf(x); if (p) p.hidden = !on;
  });
  tabs.forEach((t, i) => {
    t.tabIndex = t.getAttribute('aria-selected') === 'true' ? 0 : -1;
    t.addEventListener('click', () => select(t));
    t.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      const next = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
      select(next); next.focus(); e.preventDefault();
    });
  });
  // Buka tab sesuai tautan (#id-panel), mis. /kajian/x/#3-menit
  const dariHash = tabs.find((t) => `#${t.getAttribute('aria-controls')}` === location.hash);
  if (dariHash) select(dariHash);
});

// ---------- Jajak pendapat ----------
document.querySelectorAll<HTMLElement>('[data-polling]').forEach((box) => {
  const opsi = box.querySelector<HTMLElement>('.polling');
  const hasil = box.querySelector<HTMLElement>('.polling-hasil');
  const api = box.dataset.api;
  opsi?.addEventListener('click', async (e) => {
    const b = (e.target as Element).closest('button');
    if (!b || !hasil) return;
    hasil.querySelector('[data-pilihan]')!.textContent = b.textContent;
    opsi.hidden = true; hasil.hidden = false; hasil.focus();
    if (api) {
      try { await fetch(`${api}/polling`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pertanyaan: box.dataset.pertanyaan, pilihan: b.textContent }) }); }
      catch { /* tetap tampilkan konfirmasi; kirim ulang bisa ditangani API */ }
    }
  });
});

// ---------- Daftar periksa (asesmen mandiri) ----------
document.querySelectorAll<HTMLElement>('[data-ceklis]').forEach((box) => {
  const cek = Array.from(box.querySelectorAll<HTMLInputElement>('input[type="checkbox"]'));
  const bar = box.querySelector<HTMLElement>('[data-ceklis-bar]');
  const teks = box.querySelector<HTMLElement>('[data-ceklis-teks]');
  const saran = box.querySelector<HTMLElement>('[data-ceklis-saran]');
  const hitung = () => {
    const n = cek.filter((c) => c.checked).length, total = cek.length, persen = Math.round((n / total) * 100);
    if (bar) bar.style.width = `${persen}%`;
    if (teks) teks.textContent = `${n} dari ${total} terpenuhi (${persen}%)`;
    if (saran) saran.textContent = persen === 100 ? 'Semua butir terpenuhi. Pertahankan dan tinjau ulang secara berkala.'
      : persen >= 60 ? 'Sudah cukup baik. Prioritaskan butir yang belum dicentang.'
      : 'Masih banyak yang perlu disiapkan. Mulai dari butir paling atas yang belum terpenuhi.';
  };
  cek.forEach((c) => c.addEventListener('change', hitung));
});
