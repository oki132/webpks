---
judul: "Kalkulator biaya internet desa"
jenis: kalkulator
tema: [ki, ed]
sasaran: "Pemerintah desa dan BUMDes"
format: "Kalkulator daring"
status: segera
ringkas: "Perkiraan biaya awal dan bulanan layanan internet desa, berdasarkan jumlah rumah tangga dan jenis jaringan."
isu: [desa-tanpa-sinyal]
---

[Segera hadir.]
