---
judul: "Templat policy brief"
jenis: templat
tema: [pd]
sasaran: "Analis kebijakan"
format: "DOCX"
status: tersedia
ringkas: "Struktur policy brief empat halaman: masalah, temuan, opsi, dan rekomendasi."
berkas: /berkas/contoh.pdf
---

[Petunjuk pengisian.]
