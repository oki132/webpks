---
judul: "Kanvas pohon masalah"
jenis: kanvas
tema: [pd]
sasaran: "Fasilitator lokakarya"
format: "PDF ukuran A1"
durasi: "90 menit"
status: tersedia
ringkas: "Lembar kerja untuk memetakan dampak, gejala, dan akar masalah bersama pemangku kepentingan."
berkas: /berkas/contoh.pdf
---

## Susunan sesi

1. Tulis dampak yang dirasakan warga (20 menit).
2. Telusuri gejala yang terlihat (20 menit).
3. Cari akar masalah dengan bertanya "mengapa" berulang kali (30 menit).
4. Sepakati akar masalah prioritas (20 menit).
