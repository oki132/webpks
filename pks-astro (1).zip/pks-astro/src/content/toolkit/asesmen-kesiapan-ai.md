---
judul: "Asesmen kesiapan instansi memakai AI"
jenis: asesmen
tema: [ai, pd]
sasaran: "Instansi pemerintah"
format: "Daftar periksa daring"
durasi: "10 menit"
status: tersedia
ringkas: "Cek kesiapan data, SDM, tata kelola, dan risiko sebelum instansi memakai AI."
isu: [tata-kelola-ai]
pertanyaan:
  - "Ada masalah layanan yang jelas yang ingin diselesaikan dengan AI."
  - "Data yang dibutuhkan tersedia, rapi, dan boleh dipakai sesuai aturan."
  - "Ada pegawai yang memahami cara kerja dan batasan AI."
  - "Keputusan yang berdampak pada warga tetap ditinjau manusia."
  - "Warga diberi tahu bila berinteraksi dengan sistem AI."
  - "Ada rencana memantau kesalahan dan bias AI setelah dipakai."
---

[Panduan membaca hasil asesmen.]
