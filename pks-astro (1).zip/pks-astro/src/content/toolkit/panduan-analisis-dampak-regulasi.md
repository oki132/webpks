---
judul: "Panduan analisis dampak regulasi digital"
jenis: templat
tema: [pd, ed]
sasaran: "Penyusun regulasi"
format: "PDF"
status: tersedia
ringkas: "Langkah menilai biaya, manfaat, dan dampak sebuah rancangan regulasi digital sebelum disahkan."
berkas: /berkas/contoh.pdf
---

[Isi panduan.]
