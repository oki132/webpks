---
judul: "Templat penilaian dampak pelindungan data (DPIA)"
jenis: templat
tema: [sd, pd]
sasaran: "Pengelola layanan digital instansi"
format: "DOCX dan PDF"
status: tersedia
ringkas: "Kerangka penilaian dampak sebelum meluncurkan layanan yang memproses data pribadi berisiko tinggi."
berkas: /berkas/contoh.pdf
regulasi: [uu-27-2022-pdp]
---

## Cara memakai

1. Isi gambaran layanan dan data yang diproses.
2. Petakan risiko bagi warga.
3. Tetapkan langkah mitigasi dan penanggung jawabnya.
4. Simpan hasilnya bersama dokumen layanan.
