---
judul: "Cek kepatuhan pelindungan data pribadi instansi"
jenis: asesmen
tema: [sd, pd]
sasaran: "Instansi pusat dan daerah"
format: "Daftar periksa daring"
durasi: "10 menit"
status: tersedia
ringkas: "Delapan pertanyaan untuk melihat seberapa siap instansi menjalankan kewajiban UU PDP."
regulasi: [uu-27-2022-pdp]
isu: [kebocoran-data]
pertanyaan:
  - "Instansi sudah menunjuk pejabat atau petugas pelindungan data pribadi."
  - "Setiap jenis data pribadi yang diproses punya dasar pemrosesan yang jelas."
  - "Ada prosedur tertulis untuk memberi tahu subjek data dalam 3 × 24 jam bila terjadi kegagalan pelindungan data."
  - "Penilaian dampak pelindungan data sudah dilakukan untuk pemrosesan berisiko tinggi."
  - "Ada aturan berapa lama data disimpan dan bagaimana data dimusnahkan."
  - "Warga bisa meminta akses, koreksi, dan penghapusan datanya lewat kanal yang jelas."
  - "Kontrak dengan pihak ketiga yang memproses data memuat kewajiban pelindungan data."
  - "Pegawai yang menangani data pribadi sudah mendapat pelatihan."
---

Gunakan daftar periksa ini sebagai titik awal diskusi di instansi Anda. Hasilnya bukan penilaian resmi kepatuhan.

Setiap butir yang belum terpenuhi bisa ditindaklanjuti dengan templat penilaian dampak dan modul belajar PDP.
