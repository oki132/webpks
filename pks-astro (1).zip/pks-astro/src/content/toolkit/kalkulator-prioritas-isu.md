---
judul: "Matriks prioritas isu"
jenis: kalkulator
tema: [pd]
sasaran: "Analis kebijakan"
format: "Spreadsheet"
status: tersedia
ringkas: "Menilai isu dari urgensi dan dampaknya untuk menentukan mana yang dikaji lebih dulu."
berkas: /berkas/contoh.csv
---

[Cara memakai matriks.]
