---
judul: "Modul pelindungan data pribadi untuk ASN"
jenis: modul
tema: [sd, td]
sasaran: "ASN pusat dan daerah"
format: "Modul daring, 4 sesi"
durasi: "4 × 45 menit"
status: tersedia
ringkas: "Dari pengertian data pribadi sampai praktik menangani permintaan warga dan insiden kebocoran."
regulasi: [uu-27-2022-pdp]
---

## Sesi

1. Apa itu data pribadi dan mengapa penting
2. Kewajiban instansi menurut UU PDP
3. Menangani permintaan hak subjek data
4. Bila terjadi kebocoran: langkah 3 × 24 jam
