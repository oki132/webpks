---
judul: "Peta pemangku kepentingan"
jenis: kanvas
tema: [pd]
sasaran: "Tim perumus kebijakan"
format: "PDF"
durasi: "60 menit"
status: tersedia
ringkas: "Memetakan siapa yang terdampak, siapa yang berpengaruh, dan bagaimana melibatkan mereka."
berkas: /berkas/contoh.pdf
---

[Petunjuk pengisian.]
