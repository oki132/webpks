---
judul: "Modul literasi AI untuk pemerintah daerah"
jenis: modul
tema: [ai, td]
sasaran: "Pimpinan dan staf pemerintah daerah"
format: "Modul daring, 3 sesi"
status: segera
ringkas: "Mengenal AI, peluang di layanan publik, dan risiko yang perlu diwaspadai."
---

[Segera hadir.]
