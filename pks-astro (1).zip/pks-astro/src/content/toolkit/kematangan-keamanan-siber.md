---
judul: "Indeks kematangan keamanan siber mandiri"
jenis: asesmen
tema: [sd]
sasaran: "Unit TI instansi"
format: "Daftar periksa daring"
status: segera
ringkas: "Mengukur tingkat kematangan keamanan siber dari tata kelola sampai pemulihan insiden."
isu: [ransomware]
---

[Segera hadir.]
