---
judul: "Indeks literasi digital per provinsi"
tema: [td]
format: [CSV]
diperbarui: 2026-10-01
sumber: "[Lembaga]"
berkas: /berkas/contoh.csv
---

[Deskripsi dan kamus data.]
