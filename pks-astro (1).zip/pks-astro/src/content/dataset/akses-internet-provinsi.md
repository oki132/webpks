---
judul: "Indikator akses internet per provinsi"
tema: [ki]
format: [CSV, XLSX]
diperbarui: 2026-10-01
sumber: "[Lembaga]"
berkas: /berkas/contoh.csv
---

[Deskripsi dan kamus data.]
