---
judul: "Inventaris regulasi digital"
tema: [sd, pd]
format: [CSV, JSON]
diperbarui: 2026-10-01
sumber: "[Lembaga]"
berkas: /berkas/contoh.csv
---

[Deskripsi dan kamus data.]
