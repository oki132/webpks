---
judul: "PKS dan [mitra] menandatangani kerja sama riset tata kelola AI"
jenis: berita
tanggal: 2026-10-15
---

[Isi berita.]
