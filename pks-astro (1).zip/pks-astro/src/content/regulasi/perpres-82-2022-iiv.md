---
nama: "Perpres 82/2022 tentang Pelindungan Infrastruktur Informasi Vital"
singkat: "Perpres IIV"
tahun: 2022
jenis: Perpres
tema: [sd]
tinjauan:
  status: "[status implementasi]"
  tujuan: "[Tujuan regulasi]"
  sudahBerjalan: "[Catatan implementasi menurut tinjauan PKS]"
  celah: "[Celah yang teridentifikasi]"
cakupan:
  - { isu: infrastruktur-vital, status: diatur }
---

[Ringkasan regulasi.]
