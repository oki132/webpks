---
nama: "Strategi Nasional Kecerdasan Artifisial 2020–2045"
singkat: "Stranas KA"
tahun: 2020
jenis: Strategi
tema: [ai]
tinjauan:
  status: "[status implementasi]"
  tujuan: "[Tujuan regulasi]"
  sudahBerjalan: "[Catatan implementasi menurut tinjauan PKS]"
  celah: "[Celah yang teridentifikasi]"
cakupan:
  - { isu: tata-kelola-ai, status: sebagian }
---

[Ringkasan regulasi.]
