---
nama: "Perpres 95/2018 tentang Sistem Pemerintahan Berbasis Elektronik"
singkat: "Perpres SPBE"
tahun: 2018
jenis: Perpres
tema: [pd]
tinjauan:
  status: "[status implementasi]"
  tujuan: "[Tujuan regulasi]"
  sudahBerjalan: "[Catatan implementasi menurut tinjauan PKS]"
  celah: "[Celah yang teridentifikasi]"
cakupan:
  - { isu: interoperabilitas-data, status: sebagian }
  - { isu: layanan-publik-digital, status: diatur }
---

[Ringkasan regulasi.]
