---
simbol: Ta
nama: "Tata kelola AI"
tema: [ai, sd, pd]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu tata kelola ai]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
