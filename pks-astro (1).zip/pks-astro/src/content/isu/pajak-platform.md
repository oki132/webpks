---
simbol: Pp
nama: "Pajak ekonomi platform"
tema: [ed]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu pajak ekonomi platform]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
