---
simbol: Ks
nama: "Kesenjangan digital antarwilayah"
tema: [ed, ki, td]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu kesenjangan digital antarwilayah]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
