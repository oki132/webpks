---
simbol: Id
nama: "Interoperabilitas data"
tema: [sd, pd]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu interoperabilitas data]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
