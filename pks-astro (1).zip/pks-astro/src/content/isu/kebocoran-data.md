---
simbol: Kd
nama: "Kebocoran data pribadi"
tema: [sd, pd, rs]
urgensi: mendesak
ringkas: "Data warga yang bocor dari layanan publik maupun swasta, lalu dipakai ulang untuk penipuan."
pohonMasalah:
  dampak:
    - Turunnya kepercayaan publik pada layanan digital
    - Kerugian ekonomi warga dan pelaku usaha
    - Risiko terhadap layanan publik dan infrastruktur vital
  gejala:
    - Kebocoran data di layanan publik dan swasta
    - Penipuan rekayasa sosial memakai data bocor
    - Serangan ransomware terhadap sistem elektronik
  akar:
    - Kapasitas dan SDM keamanan siber di instansi masih terbatas
    - Standar tata kelola data belum seragam antarinstansi
    - Literasi keamanan digital masyarakat belum merata
    - Kelembagaan pelindungan data masih berproses
diperbarui: 2026-10-01
---

Isu ini mempertemukan keamanan siber, tata kelola pemerintahan digital, dan kesehatan ruang digital. [Uraian lengkap isu dari kajian PKS.]
