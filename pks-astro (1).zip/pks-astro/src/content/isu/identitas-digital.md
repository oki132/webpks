---
simbol: Ig
nama: "Identitas digital"
tema: [pd]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu identitas digital]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
