---
simbol: Pj
nama: "Penipuan & judi daring"
tema: [rs, ed]
urgensi: mendesak
ringkas: "[Ringkasan singkat isu penipuan & judi daring]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
