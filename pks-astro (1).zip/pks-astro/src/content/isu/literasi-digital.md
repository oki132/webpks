---
simbol: Ld
nama: "Literasi digital"
tema: [td]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu literasi digital]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
