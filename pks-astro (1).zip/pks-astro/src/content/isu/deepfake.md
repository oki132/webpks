---
simbol: Df
nama: "Deepfake & disinformasi"
tema: [rs]
urgensi: laten
ringkas: "[Ringkasan singkat isu deepfake & disinformasi]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
