---
simbol: Pa
nama: "Pelindungan anak"
tema: [rs]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu pelindungan anak]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
