---
simbol: Um
nama: "UMKM digital"
tema: [ed]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu umkm digital]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
