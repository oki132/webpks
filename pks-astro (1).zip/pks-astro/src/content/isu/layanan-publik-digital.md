---
simbol: Lp
nama: "Layanan publik digital"
tema: [pd]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu layanan publik digital]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
