---
simbol: Ka
nama: "Kesiapan adopsi AI"
tema: [ai]
urgensi: berkembang
ringkas: "[Ringkasan singkat isu kesiapan adopsi ai]"
pohonMasalah:
  dampak: ["[Dampak]"]
  gejala: ["[Gejala]"]
  akar: ["[Akar masalah]"]
diperbarui: 2026-10-01
---

[Uraian isu — contoh, ganti dengan hasil kajian.]
