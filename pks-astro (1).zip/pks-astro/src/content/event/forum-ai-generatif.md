---
judul: "Forum kebijakan: AI generatif di layanan publik"
jenis: forum
tanggal: 2026-10-08
waktu: "09.00–12.00 WIB"
tempat: "[Lokasi]"
tema: [ai]
rekaman: "https://[url-rekaman]"
---

[Deskripsi acara.]
