---
judul: "Kewajiban pelindungan data pribadi bagi instansi"
jenis: webinar
tanggal: 2026-11-12
waktu: "13.00–15.00 WIB"
tempat: "Daring, [platform]"
tema: [sd, pd]
---

[Deskripsi acara.]
