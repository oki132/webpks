---
judul: "Kesenjangan digital di wilayah 3T"
jenis: diskusi-terpumpun
tanggal: 2026-11-19
waktu: "09.00–12.00 WITA"
tempat: "[Kota], undangan terbatas"
tema: [ki, td]
terbuka: false
---

[Deskripsi acara.]
