---
judul: "Peluncuran Laporan Lanskap Digital Indonesia 2026"
jenis: peluncuran
tanggal: 2026-11-27
waktu: "09.00–12.30 WIB"
tempat: "[Lokasi] dan siaran langsung"
tema: [ai, sd, ki]
penting: true
susunan:
  - { jam: "09.00", acara: "Registrasi" }
  - { jam: "09.30", acara: "Sambutan [pimpinan lembaga induk]" }
  - { jam: "09.45", acara: "Paparan utama laporan" }
  - { jam: "10.30", acara: "Diskusi panel: dari data ke kebijakan" }
  - { jam: "12.15", acara: "Penutupan" }
pembicara:
  - { nama: "[Nama pembicara]", peran: "Kepala Pusat Kebijakan Strategis" }
  - { nama: "[Nama pembicara]", peran: "[Pakar], [universitas]" }
---

Peluncuran laporan tahunan yang merangkum kondisi digital Indonesia. Terbuka untuk umum.
