---
judul: "Indeks kesenjangan digital antarwilayah"
jenis: working-paper
tema: [ki, td]
tahap: pengumpulan-data
perkiraanTerbit: "[bulan tahun]"
penulis: ["[Nama peneliti]"]
ringkasan30: "[Satu kalimat temuan utama: apa yang perlu dilakukan dan mengapa sekarang]"
isu: []
regulasi: []
unggulan: false
---

## Latar

[Dua sampai tiga paragraf ringkas tentang konteks masalah.]

## Temuan

[Temuan utama dengan data pendukung.]

## Opsi kebijakan

[Dua atau tiga opsi beserta untung-ruginya.]

## Rekomendasi

[Rekomendasi dan pihak yang dituju.]
