---
judul: "Menutup celah penipuan daring: peran platform dan perbankan"
jenis: policy-brief
tema: [rs, ed]
tahap: terbit
tanggalTerbit: 2026-10-05
berkas: /berkas/contoh.pdf
penulis: ["[Nama peneliti]"]
ringkasan30: "[Satu kalimat temuan utama: apa yang perlu dilakukan dan mengapa sekarang]"
isu: [penipuan-daring]
regulasi: []
unggulan: false
---

## Latar

[Dua sampai tiga paragraf ringkas tentang konteks masalah.]

## Temuan

[Temuan utama dengan data pendukung.]

## Opsi kebijakan

[Dua atau tiga opsi beserta untung-ruginya.]

## Rekomendasi

[Rekomendasi dan pihak yang dituju.]
