---
judul: "Arsitektur kelembagaan pelindungan data pribadi: opsi dan implikasinya"
jenis: policy-paper
tema: [sd, pd]
tahap: terbit
tanggalTerbit: 2026-10-20
berkas: /berkas/contoh.pdf
penulis: ["[Nama peneliti]"]
ringkasan30: "[Satu kalimat temuan utama: apa yang perlu dilakukan dan mengapa sekarang]"
isu: [kebocoran-data]
regulasi: [uu-27-2022-pdp]
unggulan: true
---

## Latar

[Dua sampai tiga paragraf ringkas tentang konteks masalah.]

## Temuan

[Temuan utama dengan data pendukung.]

## Opsi kebijakan

[Dua atau tiga opsi beserta untung-ruginya.]

## Rekomendasi

[Rekomendasi dan pihak yang dituju.]
