---
judul: "Kesiapan kelembagaan pelindungan data pribadi di instansi pusat dan daerah"
jenis: policy-paper
tema: [sd, pd]
tahap: analisis
perkiraanTerbit: "[bulan tahun]"
penulis: ["[Nama peneliti]"]
ringkasan30: "[Satu kalimat temuan utama: apa yang perlu dilakukan dan mengapa sekarang]"
isu: [kebocoran-data]
regulasi: [uu-27-2022-pdp]
unggulan: false
---

## Latar

[Dua sampai tiga paragraf ringkas tentang konteks masalah.]

## Temuan

[Temuan utama dengan data pendukung.]

## Opsi kebijakan

[Dua atau tiga opsi beserta untung-ruginya.]

## Rekomendasi

[Rekomendasi dan pihak yang dituju.]
