---
judul: "Mengukur kesenjangan digital antarwilayah: usulan indeks komposit"
jenis: working-paper
tema: [ki, td]
tahap: terbit
tanggalTerbit: 2026-09-12
berkas: /berkas/contoh.pdf
penulis: ["[Nama peneliti]"]
ringkasan30: "[Satu kalimat temuan utama: apa yang perlu dilakukan dan mengapa sekarang]"
isu: [kesenjangan-digital]
regulasi: []
unggulan: false
---

## Latar

[Dua sampai tiga paragraf ringkas tentang konteks masalah.]

## Temuan

[Temuan utama dengan data pendukung.]

## Opsi kebijakan

[Dua atau tiga opsi beserta untung-ruginya.]

## Rekomendasi

[Rekomendasi dan pihak yang dituju.]
