---
judul: "Pedoman penggunaan AI generatif di layanan publik"
jenis: policy-paper
tema: [ai]
tahap: konsultasi
perkiraanTerbit: "[bulan tahun]"
penulis: ["[Nama peneliti]"]
ringkasan30: "[Satu kalimat temuan utama: apa yang perlu dilakukan dan mengapa sekarang]"
isu: [tata-kelola-ai]
regulasi: [stranas-ka]
konsultasi: pedoman-ai-generatif
unggulan: false
---

## Latar

[Dua sampai tiga paragraf ringkas tentang konteks masalah.]

## Temuan

[Temuan utama dengan data pendukung.]

## Opsi kebijakan

[Dua atau tiga opsi beserta untung-ruginya.]

## Rekomendasi

[Rekomendasi dan pihak yang dituju.]
