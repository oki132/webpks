---
judul: "Percepat aturan pelaksana dan kelembagaan PDP"
tema: [sd, pd]
ditujukanKepada: "[Instansi tujuan]"
status: dibahas
kajian: kelembagaan-pdp
catatan:
  - { tanggal: 2026-10-15, status: "Dibahas", isi: "Rapat pembahasan bersama [instansi tujuan]." }
  - { tanggal: 2026-09-01, status: "Diserahkan", isi: "Rekomendasi diserahkan secara resmi." }
---

[Isi rekomendasi.]
