---
judul: "Internet desa yang dikelola BUMDes"
pelaksana: "[Pemerintah desa]"
wilayah: "Nusa Tenggara Timur"
tema: [ki, ed]
pelajaran: "Model pembiayaan lokal untuk wilayah yang tidak dilirik operator."
---

Contoh praktik baik — ganti dengan kurasi PKS.
