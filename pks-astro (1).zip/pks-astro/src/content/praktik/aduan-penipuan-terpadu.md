---
judul: "Pusat aduan penipuan daring terpadu"
pelaksana: "[Pemerintah kota]"
wilayah: "[Kota]"
tema: [rs]
pelajaran: "Satu kanal aduan yang terhubung ke bank dan kepolisian."
---

Contoh praktik baik.
