---
judul: "Mengapa literasi digital perlu diukur sampai tingkat desa"
jenis: opini
penulis: "[Nama penulis]"
afiliasi: "Peneliti PKS"
tema: [td]
tanggal: 2026-10-28
ringkas: "Satu angka nasional tidak cukup untuk memutuskan di mana pelatihan harus dimulai."
---

Setiap tahun kita punya satu angka nasional untuk literasi digital. Angka itu berguna untuk melihat arah, tetapi hampir tidak berguna untuk menentukan di mana program pelatihan harus dimulai.

Di satu kabupaten, desa di pusat kecamatan dan desa di balik bukit bisa punya kondisi yang sangat berbeda. Rata-rata menyembunyikan perbedaan itu.

Usulan kami sederhana: mulai dari kabupaten percontohan, susun indikator minimum yang bisa diisi pendamping desa, dan terbitkan hasilnya secara terbuka.
