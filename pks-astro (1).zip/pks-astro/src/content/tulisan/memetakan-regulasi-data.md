---
judul: "Apa yang kami pelajari dari tiga bulan memetakan regulasi data"
jenis: catatan-riset
penulis: "[Nama penulis]"
afiliasi: "Peneliti PKS"
tema: [sd, pd]
tanggal: 2026-10-10
ringkas: "Cerita di balik penyusunan peta celah regulasi."
---

[Isi tulisan.]
