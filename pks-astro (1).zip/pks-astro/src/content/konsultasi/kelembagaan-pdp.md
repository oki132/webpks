---
judul: "Rancangan rekomendasi kelembagaan PDP"
tema: [sd, pd]
dibuka: 2026-07-01
ditutup: 2026-08-01
status: ditutup
bagian:
  - { judul: "Opsi kelembagaan", isi: "[Isi bagian]" }
tindakLanjut:
  - { masukan: "[Ringkasan masukan: perlu masa transisi bagi instansi daerah]", tindakan: "[Masa transisi ditambahkan ke rekomendasi]", status: diakomodasi }
  - { masukan: "[Ringkasan masukan]", tindakan: "[Dijadikan bahan kajian lanjutan]", status: dipertimbangkan }
---

[Pengantar konsultasi.]
