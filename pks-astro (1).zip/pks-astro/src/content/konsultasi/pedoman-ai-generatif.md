---
judul: "Rancangan pedoman penggunaan AI generatif di layanan publik"
tema: [ai]
dibuka: 2026-10-25
ditutup: 2026-11-25
status: dibuka
bagian:
  - { judul: "Ruang lingkup", isi: "Pedoman berlaku bagi instansi pemerintah yang memakai AI generatif untuk menyusun dokumen, melayani pertanyaan publik, atau membantu analisis." }
  - { judul: "Penggunaan yang dibolehkan dan dilarang", isi: "Penggunaan untuk keputusan yang berdampak langsung pada hak warga wajib melalui tinjauan manusia." }
  - { judul: "Transparansi kepada warga", isi: "Warga berhak tahu bila sedang berinteraksi dengan sistem AI, dan berhak meminta penjelasan." }
  - { judul: "Pelindungan data", isi: "Data pribadi warga tidak boleh dimasukkan ke layanan AI yang tidak memenuhi standar pelindungan data." }
---

[Pengantar konsultasi.]
