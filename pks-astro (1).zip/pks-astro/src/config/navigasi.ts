/**
 * SATU-SATUNYA sumber struktur menu. Header (dropdown), footer, dan kartu submenu
 * di setiap halaman menu membaca dari sini. Ubah menu cukup di file ini.
 */
export interface SubMenu { nama: string; href: string; ket: string }
export interface Menu { nama: string; href: string; ket: string; baru?: boolean; sub: SubMenu[] }

export const MENU: Menu[] = [
  { nama: 'Lanskap', href: '/lanskap/', ket: 'Gambaran besar kondisi digital dan isu-isunya.', sub: [
    { nama: 'Peta & indikator', href: '/lanskap/#peta', ket: 'Elemen isu, indikator, dan data per wilayah' },
    { nama: 'Isu strategis', href: '/lanskap/#isu', ket: 'Daftar isu dan tingkat urgensinya' },
  ] },
  { nama: 'Kebijakan', href: '/kebijakan/', ket: 'Aturan yang ada, pembandingnya, dan rekomendasi kami.', sub: [
    { nama: 'Regulasi', href: '/kebijakan/#regulasi', ket: 'Inventaris, peta celah, dan linimasa' },
    { nama: 'Benchmark', href: '/kebijakan/#benchmark', ket: 'Negara lain dan praktik baik daerah' },
    { nama: 'Rekomendasi', href: '/kebijakan/#rekomendasi', ket: 'Pelacak tindak lanjut rekomendasi PKS' },
  ] },
  { nama: 'Pustaka', href: '/pustaka/', ket: 'Produk kajian, data terbuka, dan tulisan.', sub: [
    { nama: 'Kajian', href: '/pustaka/#kajian', ket: 'Policy paper, brief, working paper, laporan tahunan' },
    { nama: 'Data', href: '/pustaka/#data', ket: 'Dataset terbuka untuk diunduh' },
    { nama: 'Tulisan & media', href: '/pustaka/#tulisan', ket: 'Opini, kolom pakar, dan catatan riset' },
  ] },
  { nama: 'Agenda', href: '/agenda/', ket: 'Acara kebijakan dan arsipnya.', sub: [
    { nama: 'Event', href: '/agenda/#event', ket: 'Acara mendatang dan kalender' },
    { nama: 'Arsip', href: '/agenda/#arsip', ket: 'Rekaman dan berita' },
  ] },
  { nama: 'Suara Publik', href: '/suara-publik/', ket: 'Tempat Anda menyampaikan pendapat.', sub: [
    { nama: 'Sampaikan pendapat', href: '/suara-publik/#pendapat', ket: 'Formulir pendapat dan pertanyaan pekan ini' },
    { nama: 'Konsultasi', href: '/suara-publik/#konsultasi', ket: 'Konsultasi terbuka, tindak lanjut, dan arsip' },
  ] },
  { nama: 'Toolkit', href: '/toolkit/', ket: 'Alat siap pakai untuk merumuskan dan menjalankan kebijakan digital.', sub: [
    { nama: 'Asesmen mandiri', href: '/toolkit/#asesmen', ket: 'Cek kesiapan dan kepatuhan instansi Anda' },
    { nama: 'Templat & panduan', href: '/toolkit/#templat', ket: 'Naskah kebijakan, DPIA, analisis dampak regulasi' },
    { nama: 'Kalkulator', href: '/toolkit/#kalkulator', ket: 'Hitung kebutuhan, biaya, dan prioritas' },
    { nama: 'Kanvas lokakarya', href: '/toolkit/#kanvas', ket: 'Lembar kerja untuk diskusi perumusan kebijakan' },
    { nama: 'Modul belajar', href: '/toolkit/#modul', ket: 'Pelatihan singkat untuk ASN dan pemerintah daerah' },
  ] },
  { nama: 'Policy AI', href: '/policy-ai/', ket: 'Alat bantu kebijakan berbasis AI.', baru: true, sub: [
    { nama: 'Asisten Regulasi', href: '/policy-ai/asisten-regulasi/', ket: 'Tanya isi regulasi, jawab dengan pasal' },
    { nama: 'Pembanding Regulasi', href: '/policy-ai/pembanding-regulasi/', ket: 'Sejajarkan dua aturan' },
    { nama: 'Peringkas Kajian', href: '/policy-ai/#peringkas', ket: 'Ringkasan 30 detik dan 3 menit' },
    { nama: 'Radar Sinyal Isu', href: '/policy-ai/#sinyal', ket: 'Isu yang mulai menguat' },
    { nama: 'Analisis Suara Publik', href: '/policy-ai/#analisis', ket: 'Mengelompokkan masukan publik' },
    { nama: 'Simulator Dampak', href: '/policy-ai/#simulator', ket: 'Skenario kebijakan, segera hadir' },
    { nama: 'Prinsip AI', href: '/policy-ai/#prinsip', ket: 'Cara kami memakai AI' },
  ] },
];

export const UTILITAS = [
  { nama: 'Tentang', href: '/tentang/' },
  { nama: 'PPID', href: '/ppid/' },
  { nama: 'Kontak', href: '/kontak/' },
];
