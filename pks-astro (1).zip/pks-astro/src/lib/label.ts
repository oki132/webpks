export const JENIS_KAJIAN = { 'policy-paper': 'Policy Paper', 'policy-brief': 'Policy Brief', 'working-paper': 'Working Paper', 'laporan-tahunan': 'Laporan Tahunan' } as const;
export const JENIS_EVENT = { peluncuran: 'Peluncuran', forum: 'Forum kebijakan', webinar: 'Webinar', 'diskusi-terpumpun': 'Diskusi terpumpun' } as const;
export const JENIS_TULISAN = { opini: 'Opini', 'kolom-pakar': 'Kolom pakar', 'catatan-riset': 'Catatan riset', 'artikel-populer': 'Artikel populer' } as const;
export const LABEL_TAHAP: Record<string, string> = { perumusan: 'Perumusan isu', 'pengumpulan-data': 'Pengumpulan data', analisis: 'Analisis', konsultasi: 'Konsultasi publik', terbit: 'Terbit' };
export const LABEL_REK: Record<string, string> = { dikaji: 'Dikaji', diserahkan: 'Diserahkan', dibahas: 'Dibahas', diterima: 'Diterima', diterapkan: 'Diterapkan' };
export const URGENSI = { mendesak: 'Mendesak', berkembang: 'Berkembang', laten: 'Laten' } as const;
export const JENIS_TOOLKIT_LABEL = { asesmen: 'Asesmen mandiri', templat: 'Templat & panduan', kalkulator: 'Kalkulator', kanvas: 'Kanvas lokakarya', modul: 'Modul belajar' } as const;
export const KET_TOOLKIT = {
  asesmen: 'Daftar periksa singkat untuk mengukur kesiapan dan kepatuhan instansi. Hasilnya langsung tampil, tidak dikirim ke mana pun.',
  templat: 'Kerangka dokumen yang bisa diunduh dan langsung diisi.',
  kalkulator: 'Alat hitung untuk memperkirakan kebutuhan, biaya, dan prioritas.',
  kanvas: 'Lembar kerja untuk lokakarya dan diskusi terpumpun.',
  modul: 'Materi belajar mandiri, dari pengenalan sampai praktik.',
} as const;
