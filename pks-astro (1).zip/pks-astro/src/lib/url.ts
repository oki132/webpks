/** Tambahkan base path (/web) ke tautan internal: url('/pustaka/') → '/web/pustaka/' */
const base = import.meta.env.BASE_URL.replace(/\/$/, '');
export const url = (p: string) => (p.startsWith('#') ? p : base + p);

export const formatTanggal = (d: Date) =>
  new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
export const tanggalPendek = (d: Date) => ({
  hari: new Intl.DateTimeFormat('id-ID', { day: '2-digit' }).format(d),
  bulan: new Intl.DateTimeFormat('id-ID', { month: 'short' }).format(d),
});
export const punya = (refs: { id: string }[], id: string) => refs.some((r) => r.id === id);

export const API = import.meta.env.PUBLIC_API_URL ?? '';
export const AI = import.meta.env.PUBLIC_AI_URL ?? '';
