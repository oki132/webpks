# Situs Pusat Kebijakan Strategis — Astro + Decap CMS

Implementasi mockup v2 (versi ringkas) sebagai situs statis Astro, disajikan di
`https://xakaspace.id/web/` oleh Apache XAMPP. Konten diisi lewat Decap CMS dan tersimpan di Git.

```
Editor ──► Decap CMS (internal) ──► GitLab (merge request) ──► CI build ──► file statis ──► Apache /web/
Pengunjung ─► formulir & polling ─► API (terpisah)      Pengunjung ─► Policy AI ─► layanan AI (terpisah)
```

## Menjalankan

```bash
npm install
npm run dev        # http://localhost:4321/web/
npm run check      # validasi skema & relasi konten
npm run build      # dist/ + indeks pencarian Pagefind
```
Butuh Node.js 20+. Salin `.env.example` ke `.env` bila API sudah tersedia.

## Struktur

```
src/config/navigasi.ts   SATU-SATUNYA sumber menu (header, footer, kartu submenu)
src/content.config.ts    Model konten: 15 koleksi beserta relasinya
src/content/<koleksi>/   Konten Markdown (diisi lewat CMS)
src/data/*.json          Konten berbentuk daftar: tema, indikator, benchmark, beranda, alat AI
src/styles/global.css    Token desain + gaya semua komponen (tanpa gaya inline → CSP ketat)
src/scripts/site.ts      Dropdown, menu ponsel, saring, tab, polling
src/components/          Komponen (lihat tabel di bawah)
src/pages/               Halaman menu + templat detail (isu, regulasi, kajian, tulisan, event, konsultasi)
cms/                     Panel Decap CMS — hanya untuk jaringan internal
deploy/                  Konfigurasi Apache XAMPP + skrip terbit manual
```

| Komponen | Kegunaan |
|---|---|
| `SiteHeader`, `SiteFooter`, `MenuHero` | Dibangun otomatis dari `navigasi.ts` |
| `KodeJalur` | Badge kode tema (SD, AI, …) |
| `GridElemen` | Elemen isu: kolom per tema + kolom "Simpul lintas tema" otomatis |
| `JalurTahap` | Jalur 5 tahap — dipakai untuk kajian *dan* pelacak rekomendasi |
| `MatriksCelah` | Peta celah regulasi, dihitung dari `cakupan` setiap regulasi |
| `PohonMasalah`, `KartuKajian`, `ItemEvent`, `JajakPendapat`, `ChatContoh` | Komponen konten |
| `Tabs` + `TabPanel`, `Saring`, `Bagian`, `DetailKepala` | Komponen tata letak |

## Model konten (ringkas)

| Koleksi | Tampil di | Otomatis |
|---|---|---|
| tema (7) | semua halaman | warna dari `.tema-xx` di CSS |
| isu | Elemen isu, daftar isu, detail isu | >1 tema → masuk kolom simpul |
| indikator | Lanskap › Indikator | — |
| regulasi | Kebijakan › Regulasi | peta celah & linimasa |
| benchmark, praktik | Kebijakan › Benchmark | — |
| kajian | Beranda, Pustaka | tahap ≠ terbit → "Sedang di jalur"; terbit → Pustaka |
| rekomendasi | Kebijakan › Rekomendasi | jalur status |
| dataset, tulisan | Pustaka | — |
| event, berita | Agenda, Beranda | event lewat tanggal → pindah ke arsip; kalender otomatis |
| konsultasi | Suara Publik | dibuka/ditutup, rekap tindak lanjut |
| toolkit | Toolkit | dikelompokkan per jenis; butir `pertanyaan` → daftar periksa interaktif |
| beranda | Beranda | pertanyaan bulan ini, angka sorotan, polling |

Relasi memakai ID (nama file). ID salah ketik membuat `npm run check` gagal, jadi tautan rusak tidak pernah terbit.

## Konsep CMS

**Peran** (diatur lewat izin GitLab):

| Peran | Hak | Di GitLab |
|---|---|---|
| Peneliti / penulis | membuat & menyunting draf | Developer |
| Editor | meninjau | reviewer merge request |
| Penanggung jawab | menyetujui terbit | Maintainer (satu-satunya yang boleh merge ke `main`) |

Di Decap tampil sebagai papan **Draf → Ditinjau → Siap terbit**. Setelah merge, CI membangun dan menerbitkan otomatis.

**Yang dikelola di mana:**
- *CMS*: semua koleksi, pengaturan beranda, unggahan PDF/CSV (`public/berkas`; untuk file besar pertimbangkan object storage seperti MinIO).
- *Kode (tim TI)*: menu (`navigasi.ts`), warna tema, tata letak.
- *Bukan CMS*: kiriman publik (pendapat, tanggapan konsultasi, polling, pendaftaran event) → API + database
  → dimoderasi di panel internal → rangkumannya diterbitkan lewat CMS di field `tindakLanjut` konsultasi.

**Menyiapkan panel:**
1. GitLab › Applications: buat aplikasi (scope `api`, non-confidential), redirect URI = alamat panel internal.
2. Isi `app_id`, `repo`, `base_url`, `api_root` di `cms/config.yml`.
3. `npm install decap-cms --no-save && cp node_modules/decap-cms/dist/decap-cms.js cms/`
4. Sajikan folder `cms/` dari server internal/VPN saja.

## API yang perlu disediakan (terpisah dari situs)

| Metode & jalur | Dari | Isi |
|---|---|---|
| `POST /pendapat` | Suara Publik | jenis, tema, isi, email (opsional) |
| `POST /konsultasi/:id/tanggapan` | Detail konsultasi | bagian, isi |
| `POST /polling` | Beranda, Suara Publik | pertanyaan, pilihan |
| `POST /event/:id/daftar` | Detail event | nama, instansi, email |

Wajib: validasi input, rate limiting, captcha self-hosted (mis. ALTCHA), CORS hanya untuk domain situs.
Tambahkan domain API ke `connect-src` dan `form-action` CSP di `deploy/pks-web.conf`.

**Policy AI** berjalan sebagai layanan terpisah (`PUBLIC_AI_URL`). Asisten Regulasi menjawab dari teks
regulasi dan kajian di repo ini (pendekatan RAG); indeksnya diperbarui setiap kali konten terbit.
Halaman `/policy-ai/asisten-regulasi/` saat ini berisi antarmuka contoh; hubungkan ke layanan saat siap.

## Terbit ke Vercel (pratinjau / demo)

`vercel.json` sudah berisi perintah build dan header keamanan. Di pengaturan proyek Vercel, isi variabel:
`BASE_PATH=/` dan `SITE_URL=https://<nama-proyek>.vercel.app`. Tanpa `BASE_PATH=/`, tautan akan mengarah ke `/web/` dan rusak.

## Terbit ke XAMPP

- Otomatis: isi variabel CI per environment: `SSH_KEY_DEPLOY`, `SSH_KNOWN_HOSTS`, `DEPLOY_USER`, `DEPLOY_HOST`.
- Manual di server: `deploy/terbitkan.sh`.
- Apache: `deploy/pks-web.conf` (Alias `/web` + header keamanan).

## Terbit ke Vercel

Proyek otomatis menyesuaikan diri saat dibangun di Vercel: situs berada di akar domain (`/`), bukan `/web/`.
`vercel.json` mengatur perintah build, header keamanan, dan (bila `cms/decap-cms.js` ada) menyertakan panel CMS di `/cms/`.
Hubungkan repo GitLab di dashboard Vercel, atau jalankan `npx vercel --prod` dari komputer.
Untuk menguji tampilan versi Vercel di komputer: `BASE_PATH=/ npm run build && npm run preview`.

## Aturan untuk pengembang

- Jangan menulis `style="..."` atau `<script>` inline — CSP akan memblokirnya. Pakai kelas di `global.css`
  dan skrip di `src/scripts/`.
- Tautan internal selalu lewat `url('/jalur/')` dari `src/lib/url.ts` (base path `/web`).
- Menambah tema: entri di `src/data/tema.json` + satu baris `.tema-xx` di `global.css`.
- Konten bertanda [kurung siku] adalah contoh/dummy.
