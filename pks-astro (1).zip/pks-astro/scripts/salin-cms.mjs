// Dipakai di Vercel: ikut sertakan panel CMS di /cms/ HANYA bila cms/decap-cms.js sudah ada di repo.
import { cpSync, existsSync } from 'node:fs';
if (existsSync('cms/decap-cms.js')) {
  cpSync('cms', 'dist/cms', { recursive: true });
  console.log('Panel CMS disalin ke dist/cms');
} else {
  console.log('cms/decap-cms.js belum ada: panel CMS tidak ikut diterbitkan');
}
