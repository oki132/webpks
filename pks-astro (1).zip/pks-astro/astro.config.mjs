// @ts-check
import { defineConfig } from 'astro/config';

/**
 * Lokasi situs:
 * - Vercel   : otomatis di akar domain (https://nama.vercel.app/)
 * - XAMPP    : https://xakaspace.id/web/
 * Bisa ditimpa dengan variabel BASE_PATH dan SITE_URL.
 */
const diVercel = !!process.env.VERCEL;
const domainVercel = process.env.VERCEL_PROJECT_PRODUCTION_URL || process.env.VERCEL_URL;
const base = process.env.BASE_PATH ?? (diVercel ? '/' : '/web');
const site = process.env.SITE_URL ?? (diVercel && domainVercel ? `https://${domainVercel}` : 'https://xakaspace.id');

export default defineConfig({
  site,
  base,
  output: 'static',
  trailingSlash: 'always',
  build: { inlineStylesheets: 'never' }, // agar CSP style-src 'self' berlaku
  vite: { build: { assetsInlineLimit: 0 } }, // jangan inline skrip ke HTML
});
